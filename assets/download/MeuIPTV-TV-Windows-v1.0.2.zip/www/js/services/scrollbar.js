/* ============================================================
   scrollbar.js — barra de rolagem VISÍVEL e ARRASTÁVEL
   ------------------------------------------------------------
   O WebView (Android e Windows/WebView2) ignora ::-webkit-scrollbar
   e/ou usa barra "overlay" que só aparece durante o gesto. Este
   módulo desenha uma barra própria, sempre visível quando a lista
   tem mais conteúdo do que cabe na tela, e permite ARRASTAR o
   polegar (dedo/mouse) ou clicar na trilha para pular.

   Vale para: SUBGRUPOS (.cat-list), grade de itens (.item-grid)
   e lista de episódios (.ser-episodes).

   Obs.: a lista de episódios (.ser-episodes) é criada/reconstruída
   a cada abertura de série, por isso o módulo re-escaneia o DOM
   periodicamente e se "re-engancha" sozinho.
   ============================================================ */
(function () {
  'use strict';

  var SELECTORS = '.cat-list, .item-grid, .ser-episodes';
  var bars = [];

  function attach(scrollEl) {
    var host = scrollEl.parentElement;
    if (!host) { return; }
    if (getComputedStyle(host).position === 'static') { host.style.position = 'relative'; }

    var track = document.createElement('div');
    track.className = 'sb-track';
    var thumb = document.createElement('div');
    thumb.className = 'sb-thumb';
    track.appendChild(thumb);
    host.appendChild(track);

    var bar = { el: scrollEl, host: host, track: track, thumb: thumb };
    bars.push(bar);

    /* rolagem (dedo, mouse, teclado ou foco programático) */
    scrollEl.addEventListener('scroll', function () { requestUpdate(bar); }, { passive: true });

    /* ---- arrastar o polegar: rola a lista ---- */
    var drag = null;
    thumb.addEventListener('pointerdown', function (ev) {
      ev.preventDefault();
      drag = {
        y: ev.clientY,
        top: scrollEl.scrollTop,
        max: scrollEl.scrollHeight - scrollEl.clientHeight,
        trackH: track.clientHeight,
        thumbH: thumb.offsetHeight
      };
      if (thumb.setPointerCapture) { thumb.setPointerCapture(ev.pointerId); }
      track.classList.add('sb-active');
    });
    thumb.addEventListener('pointermove', function (ev) {
      if (!drag) { return; }
      var range = Math.max(1, drag.trackH - drag.thumbH);
      var delta = (ev.clientY - drag.y) * (drag.max / range);
      scrollEl.scrollTop = drag.top + delta;
    });
    function endDrag(ev) {
      if (!drag) { return; }
      drag = null;
      track.classList.remove('sb-active');
      if (thumb.releasePointerCapture && ev && ev.pointerId !== undefined) {
        try { thumb.releasePointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
      }
    }
    thumb.addEventListener('pointerup', endDrag);
    thumb.addEventListener('pointercancel', endDrag);

    /* ---- tocar na trilha: salta para a posição ---- */
    track.addEventListener('pointerdown', function (ev) {
      if (ev.target === thumb) { return; }
      var rect = track.getBoundingClientRect();
      var ratio = (ev.clientY - rect.top) / Math.max(1, rect.height);
      scrollEl.scrollTop = ratio * (scrollEl.scrollHeight - scrollEl.clientHeight);
    });

    requestUpdate(bar);
  }

  /* engata a barra em listas novas (inclusive criadas dinamicamente) */
  function scan() {
    var found = document.querySelectorAll(SELECTORS);
    for (var i = 0; i < found.length; i++) {
      var host = found[i].parentElement;
      if (!host || host.getAttribute('data-sb') === '1') { continue; }
      host.setAttribute('data-sb', '1');
      attach(found[i]);
    }
  }

  var pending = false;
  function requestUpdate() {
    if (pending) { return; }
    pending = true;
    (window.requestAnimationFrame || function (f) { setTimeout(f, 16); })(function () {
      pending = false;
      /* descarta barras cuja lista saiu do DOM (telas reconstruídas) */
      for (var i = bars.length - 1; i >= 0; i--) {
        if (!bars[i].el.isConnected) {
          if (bars[i].track.parentNode) { bars[i].track.parentNode.removeChild(bars[i].track); }
          bars.splice(i, 1);
        }
      }
      for (var j = 0; j < bars.length; j++) { update(bars[j]); }
    });
  }

  function update(bar) {
    var se = bar.el, track = bar.track, thumb = bar.thumb;
    var sh = se.scrollHeight, ch = se.clientHeight;

    if (sh <= ch + 4) { track.classList.remove('sb-on'); return; }

    var hostRect = bar.host.getBoundingClientRect();
    var seRect = se.getBoundingClientRect();

    /* posiciona a trilha exatamente sobre a área da lista visível */
    track.style.top = (seRect.top - hostRect.top) + 'px';
    track.style.height = seRect.height + 'px';

    var trackH = seRect.height;
    var thumbH = Math.max(48, Math.round(trackH * ch / sh));
    thumb.style.height = thumbH + 'px';

    var ratio = se.scrollTop / Math.max(1, (sh - ch));
    var maxTop = Math.max(0, trackH - thumbH);
    thumb.style.transform = 'translateY(' + Math.round(ratio * maxTop) + 'px)';

    track.classList.add('sb-on');
  }

  function init() {
    scan();
    if (window.__sbTimer) { clearInterval(window.__sbTimer); }
    /* manutenção periódica: pega listas novas, mudança de conteúdo,
       foco (controle remoto/teclado) e redimensionamento */
    window.__sbTimer = setInterval(function () { scan(); requestUpdate(); }, 400);
    window.addEventListener('resize', requestUpdate);
    document.addEventListener('focusin', requestUpdate);
    document.addEventListener('keyup', requestUpdate);
    document.addEventListener('touchend', requestUpdate);
    document.addEventListener('mouseup', requestUpdate);
    requestUpdate();
  }

  window.Scrollbars = { init: init, refresh: requestUpdate };
})();
